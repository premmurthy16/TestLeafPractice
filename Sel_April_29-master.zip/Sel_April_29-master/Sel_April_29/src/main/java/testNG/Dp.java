package testNG;

import org.testng.annotations.DataProvider;

public class Dp {
	
	@DataProvider(name = "fetchData")
	public static String[][] getData(){		
		String[][] testData = new String[2][3];
		
		testData[0][0] = "TestLeaf";
		testData[0][1] = "Babu";
		testData[0][2] = "M";
		
		testData[1][0] = "TestLeaf";
		testData[1][1] = "Gopi";
		testData[1][2] = "J";
		
		testData[2][0] = "TestLeaf";
		testData[2][1] = "Nesa";
		testData[2][2] = "M";
		return testData;		
	}

}
