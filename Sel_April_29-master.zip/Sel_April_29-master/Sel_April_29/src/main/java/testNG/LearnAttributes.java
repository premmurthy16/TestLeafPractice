package testNG;

import org.testng.annotations.Test;

public class LearnAttributes {
	//priority=1
	//@Test(/*dependsOnMethods={"createLead"}*/)
	//(priority=1)
	
	
	@Test(dependsOnMethods = {"createLead"},  alwaysRun = true)	
	public void editLead(){
		System.out.println("Executing editLead");
	}
	@Test(expectedExceptions={RuntimeException.class},successPercentage=90)
	public void createLead(){
		System.out.println("Executing createLead");
		throw new RuntimeException();
	}	
	@Test(enabled=false, alwaysRun=true)
	public void deleteLead(){
		System.out.println("Executing deleteLead");
	}
	
	
}
