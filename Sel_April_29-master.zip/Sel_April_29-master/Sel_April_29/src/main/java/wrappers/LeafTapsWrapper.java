package wrappers;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

public class LeafTapsWrapper extends GenericWrappers {


	@Parameters({"url", "userName", "password"})
	@BeforeMethod(groups ={"common"})
	public void login(String url, String uName, String pwd) throws Exception {
		invokeApp("chrome", url);
		enterById("username", uName);
		enterById("password", pwd);
		clickByClassName("decorativeSubmit");
		clickByLink("CRM/SFA");	
	}
	
	@AfterMethod(groups ={"common"})
	public void closeBrowser(){
		quitBrowser();
	}
	
	/*
	@DataProvider(name = "fetchData")
	public String[][] getData(){		
		String[][] testData = new String[2][3];
		
		testData[0][0] = "TestLeaf";
		testData[0][1] = "Gopi";
		testData[0][2] = "M";
		
		testData[1][0] = "TestLeaf";
		testData[1][1] = "Sarath";
		testData[1][2] = "M";
		return testData;		
	}*/
	
}
