package leaf.Lead;

import org.testng.annotations.Test;

import testNG.Dp;
import wrappers.LeafTapsWrapper;

public class CreateLead extends LeafTapsWrapper{


	@Test(dataProvider = "fetchData", dataProviderClass = Dp.class)
	public void createLead(String cName, String fName, String lName) throws Exception{		
		clickByLink("Leads");
		clickByLink("Create Lead");
		enterById("createLeadForm_companyName",cName);
		enterById("createLeadForm_firstName", fName);
		enterById("createLeadForm_lastName", lName);		
		enterById("createLeadForm_primaryEmail", "gopinath@testleaf.com");
		enterById("createLeadForm_primaryPhoneNumber", "9597704568");
		clickByName("submitButton");		
	}	
	
	
	/*@DataProvider(name = "fetchData")
	public String[][] getData(){		
		String[][] testData = new String[2][3];
		
		testData[0][0] = "TestLeaf";
		testData[0][1] = "Babu";
		testData[0][2] = "M";
		
		testData[1][0] = "TestLeaf";
		testData[1][1] = "Nesa";
		testData[1][2] = "M";
		return testData;		
	}*/


}









